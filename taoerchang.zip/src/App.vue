<script setup lang="ts"></script>

<template>
  <router-view />
</template>

<style scoped>
/* 全局样式已在style.css中定义 */
</style>
