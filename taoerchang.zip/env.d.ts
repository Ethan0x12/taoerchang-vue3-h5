/// <reference types="vite/client" />
/// <reference path="./src/types/index.ts" />
